/*
 * myLCD.h
 *
 *  Created on: 2021��6��23��
 *      Author: Dell
 */

#ifndef SRC_MYLCD_H_
#define SRC_MYLCD_H_

extern void LCD_Init();
extern void LCD_Display(long IntDeg);
extern void LCD_Init_AUTO();
extern void LCD1S_Display();
extern void LCD5S_Display();
extern void LCD15S_Display();
extern void LCD30S_Display();
extern void LCD60S_Display();
extern void Error_Display();

#endif /* SRC_MYLCD_H_ */
