/*
 * myADC.h
 *
 *  Created on: 2021��6��23��
 *      Author: Dell
 */

#ifndef SRC_MYADC_H_
#define SRC_MYADC_H_

#include "stdint.h"

extern void InitADC(void);
extern uint16_t GetADCValue(void);



#endif /* SRC_MYADC_H_ */
