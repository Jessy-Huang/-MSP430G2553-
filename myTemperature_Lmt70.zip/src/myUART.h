/*
 * myUART.h
 *
 *  Created on: 2021��6��24��
 *      Author: Dell
 */

#ifndef SRC_MYUART_H_
#define SRC_MYUART_H_

#include "stdint.h"

extern void InitUART(void);
extern void UARTSendString(uint8_t *pbuff,uint8_t num);
extern void PrintNumber(uint16_t num);
extern void PrintFloat(float num);
extern void myPrintFloat(float num);



#endif /* SRC_MYUART_H_ */
