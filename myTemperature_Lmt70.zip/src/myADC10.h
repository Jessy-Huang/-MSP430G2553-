/*
 * ADC10.h
 *
 *  Created on: 2021��6��23��
 *      Author: Dell
 */

#ifndef SRC_ADC10_H_
#define SRC_ADC10_H_

extern void ADC10_init(void);
//extern void ADC10_init(void);


#endif /* SRC_ADC10_H_ */
