/*
 * DAC8411.h
 *
 *  Created on: 2021��6��23��
 *      Author: Dell
 */

#ifndef DAC8411_H_
#define DAC8411_H_

extern void DAC8411_Init(void);
extern void write2DAC8411(unsigned int Data);



#endif /* DAC8411_H_ */
